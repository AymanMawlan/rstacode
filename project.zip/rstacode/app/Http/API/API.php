<?php
namespace App\Http\API;
class API {
    public static function Video($mediaID){
        if(!empty($mediaID)){
        $curl = curl_init();
        curl_setopt_array($curl, array(
        CURLOPT_URL => "https://dev.vdocipher.com/api/videos/$mediaID",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "GET",
        CURLOPT_HTTPHEADER => array(
        "Accept: application/json",
        "Content-Type: application/json"
        ),
        CURLOPT_HTTPHEADER => array(
        "Accept: application/json",
        "Authorization: Apisecret YOUR_SECRET",
        "Content-Type: application/json"
         ),
        ));
        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        return json_decode($response, true);
  
}else{
    exit("404");
}
}
}
