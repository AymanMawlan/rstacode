<?php
namespace App\Http\Controllers\Auth;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Livewire\Component;
use App\Models\User;
use Validator;
use Socialite;
use Auth;
use Exception;
Use \Carbon\Carbon;

class SocialAPI extends Controller
{
    
    public function redirectToProvider($provider){
        return Socialite::driver($provider)->redirect();
    }
    public function handleProviderCallback($provider){
        try {
            $user = Socialite::driver($provider)->user();
            $finduser = User::where($provider.'_id', $user->id)->orWhere('email' , $user->email)->first();
            if($finduser){
                Auth::login($finduser);
                return redirect('/home');
            }else{
                $newUser = User::create([
                    'name' => $user->name,
                    'email' => $user->email,
                    $provider.'_id'=> $user->id,
                    'email_verified_at' =>now(),
                    'password' => null,
                    'picture' => $user->avatar,
                    'rule' => 1,
                ]);
                Auth::login($newUser);
                return redirect('/home');
            }
        } catch (Exception $e) {
            // To Show Error
            // dd($e->getMessage());
            return redirect('/home');
        }
    }
}
