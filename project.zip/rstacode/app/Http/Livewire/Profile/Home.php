<?php

namespace App\Http\Livewire\Profile;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Livewire\Component;
use App\Models\part_profile;
use App\Models\alert_balance;
use Auth;
use Mail;
use App\Mail\AlertBalance;

class Home extends Component
{
    public $parts;
    public $balance;
    public $phonenumber;

    protected $rules = [
        'balance' => 'required|numeric',
        'phonenumber' => ['required','regex:/^(?:079|078|077|076|075|074|073)[0-9]{8}/'],
    ];
    public function checkout(){
        $this->validate();
        alert_balance::create([
            'user_id' => Auth::id(),
            'balance' => abs(str_replace(".", "", $this->balance)),
            'phonenumber' => $this->phonenumber,
            'status' => 1
        ]);
        Mail::to("rstacode@gmail.com")->send(new AlertBalance());
        return redirect()->to('/home/transaction');
    }
    public function mount(){
        $this->parts = part_profile::all();
    }
    public function render()
    {
        return view('livewire.profile.home')->extends('layouts.app');
    }
}
