<?php
namespace App\Http\Livewire\Profile;
use Livewire\Component;
use App\Models\order_course;
use Livewire\WithPagination;
use Auth;
class OrderCourses extends Component
{
    use WithPagination;
    protected $paginationTheme = 'bootstrap';

    public function render()
    {
        $array = [
            'myOrderCourse' => order_course::where('user_id' , Auth::id())->latest()->paginate(30),
        ];
        return view('livewire.profile.order-courses' , $array)->extends('layouts.app');
    }
}
