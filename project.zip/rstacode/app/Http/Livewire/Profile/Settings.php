<?php

namespace App\Http\Livewire\Profile;

use Livewire\Component;
use App\Models\User;
use Auth;
use Livewire\WithFileUploads;
use Image;
use File;

use App\Models\alert_balance;
use App\Models\order_course;

class Settings extends Component
{
    use WithFileUploads;

    public $name;
    public $picture;
    protected $rules = [
        'name' => 'required|min:2',
        'picture' => 'file|mimes:png,jpg,jpeg,webp'
    ];
    public function mount(){
        $this->name = Auth::user()->name;
    }
    public function changeName(){
        $this->validateOnly('name');
        if($this->name != Auth::user()->name){
        User::where('id' , Auth::id())->update(['name' => $this->name]);
        }
    }
    public function changePicture(){
        $this->validateOnly('picture');
        $filename = md5(date('ymdsiydsiy')).".jpg";
        if(File::exists('upload/picture/'.Auth::user()->picture) && Auth::user()->picture != Auth::user()->gender.".svg" ){
            unlink('upload/picture/'.Auth::user()->picture);
        }
        Image::make($this->picture)->fit(400,400)->save('upload/picture/'.$filename , 30);
        User::where('id',Auth::id())->update(['picture' => $filename]);
        return redirect()->to('/home/settings');
    }
    public function deleteAccount(){
        alert_balance::where('user_id' , Auth::id())->delete();
        order_course::where('user_id' , Auth::id())->delete();
        User::where('id' , Auth::id())->delete();
        return redirect()->to('/');
        Auth::logout();
    }
    public function render()
    {
        return view('livewire.profile.settings')->extends('layouts.app');;
    }
}
