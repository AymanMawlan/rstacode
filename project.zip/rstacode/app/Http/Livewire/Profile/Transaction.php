<?php

namespace App\Http\Livewire\Profile;

use Livewire\Component;
use App\Models\alert_balance;
use Auth;
use Livewire\WithPagination;

class Transaction extends Component
{
    use WithPagination;
    protected $paginationTheme = 'bootstrap';
    public function render()
    {
        $array = [
            'transactions' => alert_balance::where('user_id' , Auth::id())->latest()->paginate(30),
        ];
        return view('livewire.profile.transaction',$array)->extends('layouts.app');
    }
}
