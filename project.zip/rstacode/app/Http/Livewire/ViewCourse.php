<?php
namespace App\Http\Livewire;
use Livewire\Component;
use App\Models\course;
use App\Models\order_course;
use App\Models\User;
use Auth;
class ViewCourse extends Component
{ 
    public $course;
    public $is_order = false;
    public $mediaID = null;

    public function order($id){
        if(Auth::check() && (Auth::user()->id == $this->course->user_id || order_course::where(['course_id' => $id , 'user_id' => Auth::user()->id])->exists())){
           return true;
        }else{
           return false;
        }
    }
   
    public function mount($id , $mediaID = null , $i = null){
        $this->course = course::findOrfail($id);
        $this->is_order = $this->order($id);
        if($this->course->is_server == 1 ){
        if($mediaID == null || $i == null){
            $this->mediaID = $this->course->json_video[0]['id'];
        }else{
            if($this->order($id) && $this->course->json_video[$i]['id'] === $mediaID && Auth::check() && array_key_exists($i , $this->course->json_video)){
                $this->mediaID = $mediaID;
            }else{
                $this->mediaID = $this->course->json_video[0]['id'];
            }
        }
        }
    }

    public function checkout(){
        if(Auth::check() && Auth::user()->balance >= $this->course->price && $this->is_order == false){
            order_course::create([
                'user_id' => Auth::id(),
                'teacher_id' => $this->course->user_id,
                'course_id' => $this->course->id,
                'price_at' => $this->course->price,
            ]);
            User::where('id' , Auth::id())->update(['balance' => Auth::user()->balance - $this->course->price]);
            return redirect()->to("/courses/".$this->course->id);
        }else{
            return "fail";
        }
    }
    
    public function render(){
        return view('livewire.view-course')->extends('layouts.app');
    }
}
