<?php

namespace App\Http\Livewire;
use Livewire\Component;
use Session;
use App\Models\course;
use Livewire\WithPagination;
class Welcome extends Component
{
    use WithPagination;
    protected $paginationTheme = 'bootstrap';
    public $search ='';

    public $bg_colors =['warning' , 'success' , 'info' , 'primary' , 'indigo','danger','default'];
    public $hex_colors = ['FB8540','2DCEA9','12A1F0','695FF3','C340ED','F64B4A','18214D'];
    public $ShowBg = false;
    
    public function toggleBg(){
        $this->ShowBg = ! $this->ShowBg;
    }
    public function updatingSearch(){
        $this->resetPage();
    } 

    public function ChangeBg($bg){
        Session::put('bg',$this->bg_colors[(int) $bg]);
        Session::put('hex',$this->hex_colors[(int) $bg]);
        return redirect()->to("/");
    }

    public function render(){
        $array = [
            'courses' => course::where('title' , 'LIKE' , '%'.$this->search.'%')->latest()->paginate(16)
        ];
        return view('livewire.welcome', $array)->extends('layouts.app');
    }
    
}
