<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
class course extends Model
{
    use HasFactory;
    public $table = "course";
    protected $fillable = ['user_id','is_server','title','description','image','price','json_video'];
  
    protected $casts = [
        'json_video' => 'array',
    ];
    public function teacher(){
        return $this->hasOne('App\Models\User', 'id', 'user_id')
        ->select([
            'id',
            'name',
            'picture',
            'github_id',
            'google_id'
        ]);
    }
 
    public function countOrder(){
        return $this->hasMany('App\Models\order_course')->where('course_id',$this->id)->select('id');
    }
   

}
