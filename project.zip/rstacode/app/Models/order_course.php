<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class order_course extends Model
{
    use HasFactory;
    public $table = "order_course";
    protected $fillable = ['user_id','teacher_id','course_id','price_at'];


    public function order(){
        return $this->hasOne('App\Models\User' , 'id' , 'user_id')->exists();
    }
    public function myOrderCourse(){
        return $this->hasMany('App\Models\course' , 'id','course_id');
    }
}
