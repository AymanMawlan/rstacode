<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class part_profile extends Model
{
    use HasFactory;
    public $table = "part_profile";
    protected $fillable = ['title','icon','bg','url'];
}
