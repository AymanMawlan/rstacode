<?php

namespace App\Rules;

use Illuminate\Contracts\Validation\Rule;

class CustomEmail implements Rule
{
    public function passes($attribute, $value)
    {
        if (
            strpos(strtolower($value), '@gmail.com') !== false
            ||
            strpos(strtolower($value), '@hotmail.com') !== false
            ||
            strpos(strtolower($value), '@yahoo.com') !== false
            ||
            strpos(strtolower($value), '@outlook.com') !== false
            ) {
            return true;
        }
        return false;
    }

    public function message()
    {
        return ' ئەم ئیمەیلانە قبوڵە  HOTMAIL , GMAIL , YAHOO , OUTLOOK' ;
    }
}
