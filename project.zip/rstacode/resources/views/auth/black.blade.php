@extends('layouts.app')
@section('content')
<div class="container text-center mt-5" data-aos="zoom-out">
    <h1 class="ion-android-warning text-yellow" style="font-size: 100px"></h1>
    <h1 class="lead">ناتوانیت بچیتە ئەم پەڕەیەوە</h1>
    <a class="text-primary" href="/about">پەیوەندیمان پێوە بکە</a>
</div>
@endsection
