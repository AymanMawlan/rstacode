@extends('layouts.app')
@section('content')
<div class="container mt-5" data-aos="zoom-out">
    <div class="card m-auto text-center" style="width: 23rem;direction:ltr !important">
        <div class="card-body">
            <div class="text-center mb-3"><small>بچۆ ژوورەوە بە </small></div>
            <div class="btn-wrapper text-center">
                <a href="/login/github" class="btn btn-white ion-social-github">
                    Github
                </a>
                <a href="/login/google" class="btn btn-white">
                    <img src="{{asset('assets/img/google.png')}}" width="20" alt="">
                    Gmail
                </a>
            </div>
            <div class="text-center my-3">
                <small>یان</small>
            </div>
            <form  method="POST" action="{{ route('login') }}">
                @csrf
                <div class="form-group mb-3">
                    <div class="input-group input-group-alternative">
                        <input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" placeholder="Email" required autocomplete="email">
                    </div>
                    @error('email')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                    @enderror
                </div>
                <div class="form-group">
                    <div class="input-group input-group-alternative">
                        <input id="password" type="password"
                            class="form-control @error('password') is-invalid @enderror" name="password" placeholder="Password" required
                            autocomplete="current-password">
                    </div>
                    @error('password')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                    @enderror
                </div>
                <div class="text-center">
                    <button type="submit" class="btn btn-primary">چوونەژوورەوە</button>
                </div>

                <div class="d-flex justify-content-between mt-4">
                    <a class="text-danger" href="{{route('password.request')}}">
                        {{ __('بیرچوونەوە') }}
                    </a>
                <a class="text-success" href="{{ route('register') }}">
                    {{ __('نوێ') }}
                </a>
                </div>
                
            </form>
        </div>
    </div>
</div>
@endsection
