@extends('layouts.app')
@section('content')
<div class="container" data-aos="zoom-out">
    <div class="card m-auto text-center" style="width: 23rem">
        <div class="card-body">
            @if (session('status'))
            <div class="alert alert-success" role="alert">
                {{ session('status') }}
            </div>
            @endif
            <form method="POST" action="{{ route('password.email') }}">
                @csrf
                <label for="email" class="text-md-right">{{ __('ئیمەیلەکەت بنوسە') }}</label>
                <div class="input-group input-group-alternative mb-3">
                    <input id="email" type="email" class="form-control @error('email') is-invalid @enderror"
                        name="email" value="{{ old('email') }}" required autocomplete="email" autofocus>
                    @error('email')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                    @enderror
                </div>

                <div class="text-center">
                    <button type="submit" class="btn btn-warning">ناردن</button>
                </div>

                <div class="d-flex justify-content-between mt-4">

                    <a class="text-primary" href="{{ route('login') }}">
                        {{ __('بیرم هاتەوە') }}
                    </a>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection
