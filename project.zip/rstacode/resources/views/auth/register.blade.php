@extends('layouts.app')

@section('content')
<div class="container" data-aos="zoom-out">
    <div class="card m-auto text-center" style="width: 23rem">
        <div class="card-body">
            <form method="POST" action="{{ route('register') }}">
                @csrf
                <div class="input-group input-group-alternative mb-3">
                    <input id="name" type="text" placeholder="ناوێکی نوێ"
                        class="form-control @error('name') is-invalid @enderror" name="name" value="{{ old('name') }}"
                        required autocomplete="name">
                    @error('name')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                    @enderror
                </div>

                <div class="input-group input-group-alternative mb-3">
                    <input id="email" type="email" placeholder="E-mail" dir="ltr"
                        class="form-control @error('email') is-invalid @enderror" name="email"
                        value="{{ old('email') }}" required autocomplete="email">
                    @error('email')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                    @enderror
                </div>

                <div class="input-group input-group-alternative mb-3">
                    <input id="password" type="password" placeholder="وشەی تێپەڕ"
                        class="form-control @error('password') is-invalid @enderror" name="password" required
                        autocomplete="new-password">
                    @error('password')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                    @enderror
                </div>

                <div class="input-group input-group-alternative mb-3">
                    <input id="password-confirm" type="password" placeholder="دووبارەکردنەوەی وشەی تێپەڕ"
                        class="form-control" name="password_confirmation" required autocomplete="new-password">
                </div>

                <div class="input-group input-group-alternative mb-3">
                    <select name="gender" class="form-control">
                        <option value="male">نێر</option>
                        <option value="female">مێ</option>
                    </select>
                </div>

                <div class="text-center">
                    <button type="submit" class="btn btn-success">زیادکردنی هەژمار</button>
                </div>
                <div class="d-flex justify-content-between mt-4">

                    <a class="text-primary" href="{{ route('login') }}">
                        {{ __('هەژمارم هەیە') }}
                    </a>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection
