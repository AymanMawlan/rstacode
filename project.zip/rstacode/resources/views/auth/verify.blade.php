@extends('layouts.app')

@section('content')
<div class="container" data-aos="zoom-out">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('ئەکاونتەکەت چالاک بکە !') }}</div>

                <div class="card-body">
                    @if (session('resent'))
                        <div class="alert alert-darker" role="alert">
                            {{ __('زۆر باشە ، تکایە سەردانی ئیمەیلەکەت بکە بۆ چالاک کردنی هەژماری ڕستەکۆد') }}
                        </div>
                    @endif

                    {{ __('پێش ئەوەی بچیتە هەژمارەکەت ئەوا تکایە سەردانی ئیمەیلەکەت بکە و هەژمارەکەت چالاک بکە ') }} <br><br>
                    {{ __('ئەگەر ئیمەیلت بۆ نەهاتووە ئەوا کلیک لە دووبارە ناردنەوە بکە') }},
                    <form class="d-inline" method="POST" action="{{ route('verification.resend') }}">
                        @csrf
                        <button type="submit" class="btn btn-link p-0 m-0 align-baseline">{{ __('دووبارە ناردنەوە') }}</button>.
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
