<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name='viewport' content='width=device-width, initial-scale=1.0, maximum-scale=1.0,user-scalable=0'>
    <meta name="turbolinks-cache-control" content="no-cache">
    <meta name="theme-color" content="#{{!session('hex') ? 'C83C94' : session('hex') }}">
    <link rel="icon" href="{{ asset('assets/img/fav.svg') }}" type="image/icon type">
    <link rel="stylesheet" href="{{asset('/assets/css/style.css')}}">
    <link rel="stylesheet" href="{{asset('/assets/css/bootstrap.css')}}">
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css">

    <script src="{{ asset('assets/lib/api.js') }}" defer data-turbolinks-track="reload"></script>
    <script src="{{ asset('assets/lib/livewire-turbolinks.js') }}" defer data-turbolinks-track="reload"></script>
    <script src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.7.3/dist/alpine.min.js" defer></script>
    <script src="https://unpkg.com/aos@next/dist/aos.js"></script>
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
    <!-- Primary Meta Tags -->
    <title>ببە باشترین پڕۆگرامەر لێرە </title>
    <meta name="title" content="ببە باشترین پڕۆگرامەر لێرە">
    <meta name="description" content="ئێمە لێرەین بۆ باشتر کردنی ئاستی تۆ ، بۆیە دەستپێ بکە لێرە ">

    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="website">
    <meta property="og:url" content="https://rstacode.info/">
    <meta property="og:title" content="ببە باشترین پڕۆگرامەر لێرە ">
    <meta property="og:description" content="ئێمە لێرەین بۆ باشتر کردنی ئاستی تۆ ، بۆیە دەستپێ بکە لێرە ">
    <meta property="og:image" content="{{asset('assets/img/meta.png')}}">

    <script async="" src="https://player.vdocipher.com/playerAssets/1.6.10/vdo.js"></script>
    <script src="{{ asset('assets/lib/apiVideo.js') }}"></script>

</head>
@livewireStyles

<body class="bg-gradient-{{session('bg')}}">
    <nav class="container navbar navbar-expand-lg navbar-dark">
        <a class="navbar-brand" href="/"><img src="{{ asset('assets/img/logo.svg') }}" width="65"></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto p-1">
                <li class="nav-item">
                </li>
            </ul>
            <div class="my-2 my-lg-0 text-right" dir="rtl">
                <a href="/{{Auth::check() ? "home" : "login"}}"
                    class="btn btn-darker my-2 my-sm-0 ml-2 ion-android-unlock"> هەژمار </a>
                <a href="/" class="btn btn-white my-2 my-sm-0 ml-2 ion-home"> دەستپێک </a>
                <a href="/about" class="btn btn-white my-2 my-sm-0 ml-2"> ڕستەکۆد کێێە ؟ </a>
                @if(Auth::check())
                <a class="btn btn-danger my-2 my-sm-0 ml-2 ion-outlet" href="{{ route('logout') }}"
                    onclick="event.preventDefault(); document.getElementById('frm-logout').submit();">
                    دەرچوون
                </a>
                <form id="frm-logout" action="{{ route('logout') }}" method="POST" style="display: none;">
                    {{ csrf_field() }}
                </form>
                @endif
                <a href="#"></a>
            </div>
        </div>
    </nav>
    <script>
  var div = document.createElement('div');
  div.className = 'fb-customerchat';
  div.setAttribute('page_id', '107883507330371');
  div.setAttribute('ref', '');
  document.body.appendChild(div);
  window.fbMessengerPlugins = window.fbMessengerPlugins || {
    init: function () {
      FB.init({
        appId            : '1678638095724206',
        autoLogAppEvents : true,
        xfbml            : true,
        version          : 'v8.0'
      });
    }, callable: []
  };
  window.fbAsyncInit = window.fbAsyncInit || function () {
    window.fbMessengerPlugins.callable.forEach(function (item) { item(); });
    window.fbMessengerPlugins.init();
  };
  setTimeout(function () {
    (function (d, s, id) {
      var js, fjs = d.getElementsByTagName(s)[0];
      if (d.getElementById(id)) { return; }
      js = d.createElement(s);
      js.id = id;
      js.src = "//connect.facebook.net/en_US/sdk/xfbml.customerchat.js";
      fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));
  }, 0);
</script>
    @yield('content')
    @livewireScripts
    <p class="text-center text-white my-4">Powered By Rstacode &copy; 2019 - {{date("Y")}} </p>
    <script>AOS.init();</script>
</body>
</html>
