<div class="container" data-aos="zoom-out">
    <div class="jumbotron text-center bg-white my-5 py-2">
        <p class="my-3 ">
            <h1 > بِسْمِ اللَّـهِ الرَّحْمَـٰنِ الرَّحِيمِ</h1><br>
        من نەشوانم ٢١ ساڵم خوێندکاری زانکۆی سلێمانیم ، زۆرم حەز بە بوارەکانی کۆمپیوتەرە چ لە نەرمەوالا یان رەقەکاڵا ، بۆیە بڕیارم داوە ئەوەی من ئەیزانم لەم بوارەداو ئەوەی پسپۆرم بیبەخشم بە گەلی کورد بەبێ جیاوازی بۆیە هەلسام بە دانانی خانەیەکی بچووک بەناوی 
        (رستەکۆد)
        رەنگە کەموو کوریم هەبێت بەڵام زۆرترین هەولم داوە بۆ ئەوەی پەیامەکە بەجوانی بگەیەنم 
        ، 
        وە سوپاسی یەک بە یەکی ئەوانە دەکەم کە تا ئێستە پشتی منیان گرتووە و هانم دەدەن لەم بوارەدا
        ، 
        بێگومان ئامانجی من چاوکرانەوە و بەرەکەتی خەرمانی زانستی گەنجانە.
        </p>
        <div class="row">
            <div class="card p-0" style="width: 15rem;">
                <img src="{{asset('upload/team/1.jpg')}}" class="card-img-top">
                <div class="card-body pb-0 d-flex justify-content-between">
                    <h5 class="card-title">نەشوان عبدللە محمد <br> <small class="text-muted">دامەزرێنەر</small></h5>
                    <a href="https://www.facebook.com/codenashwan" target="_blank" class="ion-social-facebook mt-2"></a>
                </div>
            </div>
        </div>
        <span>ڕستەکۆد تەنها ئەم تۆڕانەی هەیە بۆ پەیوەندیکردن</span>
        <div class="d-flex justify-content-center my-2">
            <a href="https://www.facebook.com/rstacode" target="_blank"  class="btn btn-facebook btn-sm mx-2 ion-social-facebook"></a>
            <a href="https://www.youtube.com/rstacode" target="_blank"  class="btn btn-youtube btn-sm mx-2 ion-social-youtube"></a>
            <a href="https://www.github.com/codenashwan" target="_blank"  class="btn btn-github btn-sm mx-2 ion-social-github"></a>
            <a href="tel:07704695176" class="btn btn-success btn-sm mx-2 ion-ios-telephone"></a>
        </div>
    </div>
</div>
