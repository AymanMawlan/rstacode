<a href="/courses/{{$value->id}}" target="{{$value->is_server == 0 ? "_blank" : "_self" }}">
    <div class="card" style="width: 18rem;">
        <img src="{{ asset("upload/courses/$value->image") }}" class="card-img-top" alt="...">
        <div class="card-body">
            <div class="d-flex justify-content-between">
                <h5 class="card-title my-1">{{$value->title}} <br> <small>{{$value->teacher->name}}</small></h5>
                <span class="avatar avatar-sm rounded-circle">
                    <img alt="Image placeholder" src="{{str_contains($value->teacher->picture, "https://") ? $value->teacher->picture :  asset('upload/picture/'.$value->teacher->picture)}}">
                </span>
            </div>
                <div class="d-flex justify-content-between mt-2 ">
                    <span
                        class="display-4">{{$value->price == 0 ? "خۆڕایی" : number_format($value->price ,0, '.' ,'.')." دینار "}}</span>
                    <span
                        class="display-4 {{$value->is_server == 0 ? "ion-social-youtube text-danger" : "ion-card"}}"></span>
                </div>
        </div>
    </div>
</a>