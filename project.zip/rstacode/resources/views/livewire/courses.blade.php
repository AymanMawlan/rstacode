<div class="container">
    @include('livewire.content.part')
    <div class="row">
        @foreach ($courses as $value)
        @include('livewire.content.card_course')
        @endforeach
    </div>
    {{ $courses->links() }}
</div>
