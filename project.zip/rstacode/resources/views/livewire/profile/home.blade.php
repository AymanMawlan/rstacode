<div>
    <div class="row">
        <div class="card col-lg-2 col-md text-center m-2" style="height: 480px">
            <div class="position-relative">
                <a href="/home/settings" class="icon-sm icon-shape bg-gradient-white rounded-circle text-white position-absolute bottom-0 m-2" title="گۆڕینی وێنەی هەژمار">
                    <i class="ion-ios-camera gradient"></i>
                </a>
            <img src="{{str_contains(Auth::user()->picture, "https://") ? Auth::user()->picture :  asset('upload/picture/'.Auth::user()->picture)}}"
                width="150" height="150" class="rounded-lg shadow mx-auto">
            </div>
            <br>
            <ul class="list-group list-group-flush pr-0" dir="ltr">
                <li
                    class="list-group-item d-flex justify-content-between align-items-center text-sm border-0">
                    {{Auth::user()->name}}
                    <span class="ion-person"></span>
                </li>
                <li
                    class="list-group-item d-flex justify-content-between align-items-center text-sm border-0">
                    {{Str::limit(Auth::user()->email , 17)}}
                    <span class="ion-ios-email"></span>
                </li>
                <li
                    class="list-group-item d-flex justify-content-between align-items-center text-sm border-0">
                    {{Auth::user()->github_id ? "Github" : (Auth::user()->google_id ? "Gmail" : "Rstacode")}}
                    <span class="text-primary ion-checkmark-circled"></span>
                </li>
                <li
                    class="list-group-item d-flex justify-content-between align-items-center text-sm border-0 bg-yellow rounded-lg shadow-sm">
                    <span
                        dir="rtl">{{number_format(Auth::user()->balance,0, '.' ,'.')." دینار "}}</span>
                    <span class="ion-card"></span>
                </li>
            </ul>
            <br>    
            <span class="btn btn-darker m-0" data-toggle="modal" data-target="#pay">زیادکردنی باڵانس</span>
            <!-- Modal -->
            <div wire:ignore.self class="modal fade" id="pay" tabindex="-1" role="dialog"
                aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-body">
                            <img src="{{asset('assets/img/fastpay.png')}}" width="100" class="my-2">
                            <p>
                                بۆ پڕکردنەوەی باڵانس پیویستە حسابی بانکی ئەلکترۆنی <a href="https://www.fast-pay.cash"
                                    target="_blank"><img src="{{asset('assets/img/fastpay.png')}}" width="50"></a>
                                ت هەبێت بە شێوازی ئاسایی پارەکە
                                بنێریت بۆ هەژماری فاستپەی ئەم ژمارە تەلەفوونە <b class="text-danger">07704695176</b>
                                لەکاتی ناردنی پارەکە لە
                                فۆڕمەکەی خوارەوە ژمارەی تەلەفوونت و بڕی پارەکە پڕبکەرەوە بۆ ئەوەی بزانین تۆیت | ئەگەر
                                دوای ٢٤ کاتژمێر باڵانست بۆ نەهات ئەوا ئاگادارمان بکەرەوە
                            </p>

                            <div class="d-flex justify-content-between">
                                <input type="tel" wire:model.defer="balance"
                                    class="@error('balance') border border-danger @enderror form-control form-control-alternative m-1"
                                    placeholder="بڕی باڵانس">
                                <input type="tel" wire:model.defer="phonenumber"
                                    class="@error('phonenumber') border border-danger @enderror text-left form-control form-control-alternative m-1"
                                    placeholder="07701234567" dir="ltr">
                            </div>
                            <div wire:loading>
                                <img src="{{asset('assets/img/load.svg')}}" width="30" class="mt-3">
                            </div>
                        </div>
                        <div class="modal-footer" wire:loading.remove>
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">لابردن</button>
                            <button wire:click="checkout" class="btn btn-dribbble">ناردن بۆ ڕستەکۆد</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-8 col-md">
            <div class="row">
                @foreach($parts as $value)
                <div class="card" style="width: 18rem;">
                    <i class="{{$value->icon}} text-{{$value->bg}} text-center" style="font-size: 30px"></i>
                    <div class="card-body">
                        <h5 class="card-title text-{{$value->bg}}">{{$value->title}}</h5>

                        <a href="{{$value->url}}" class="btn btn-{{$value->bg}} ion-ios-arrow-back" dir="ltr"> سەردان
                        </a>
                    </div>
                </div>
                @endforeach
            </div>
        </div>
    </div>
</div>
