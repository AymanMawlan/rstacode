<div class="container">
    <div class="bg-white p-1 rounded d-flex justify-content-between">
        <a href="/home" class="btn btn-darker ion-ios-undo rounded  "></a>
       <span class="btn"> ئەو خولانەی کە کڕیومن</span>
    </div>
    <div class="alert bg-yellow text-right my-2">ئەو خولانەی کە کڕیوتن و ئێستە بوونەتە خۆڕایی , بۆیە لە یوتوبەکەمان بەردەستە</div>
    <div class="row">
        @foreach ($myOrderCourse as $orderCourse)
        @foreach ($orderCourse->myOrderCourse as $value)
        @include('livewire.content.card_course')
        @endforeach
    @endforeach
    </div>
    {{ $myOrderCourse->links() }}
</div>
