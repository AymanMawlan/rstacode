<div class="container">
    <div class="bg-white p-1 rounded d-flex justify-content-between">
        <a href="/home" class="btn btn-darker ion-ios-undo rounded  "></a>
        <span class="btn">ڕێکخستنەکان</span>
    </div>

    <div class="row">
        <div class="col-lg-3 col-sm">
            <div class="card">
                <p>گۆڕینی وێنەی هەژمار</p>
                <img src="{{str_contains(Auth::user()->picture, "https") ? Auth::user()->picture :  asset('upload/picture/'.Auth::user()->picture)}}"
                    width="150" height="150" class="rounded-lg shadow mx-auto">
                <input type="file" wire:model="picture"
                    class="@error('picture') border border-danger @enderror form-control border my-3 border-lighter text-center" style="overflow: hidden;">
                <div class="text-center my-3" wire:loading wire:target="changePicture">
                    <img src="{{asset('assets/img/load.svg')}}" width="30">
                </div>

                <span class="btn btn-darker" wire:click="changePicture">گۆڕین</span>
            </div>
        </div>


        <div class="col-lg-4 col-sm">
            <div class="card">
                <p>گۆڕینی ناوی هەژمار</p>
                <input type="text" wire:model.defer="name" dir="ltr"
                    class="@error('name') border border-danger @enderror form-control form-control-alternative border my-3 border-lighter text-center"
                    value="{{Auth::user()->name}}" placeholder="ناوی هەژمار">
                <div class="text-center my-3" wire:loading wire:target="changeName">
                    <img src="{{asset('assets/img/load.svg')}}" width="30">
                </div>

                <span class="btn btn-darker" wire:click="changeName">گۆڕین</span>
            </div>
        </div>

        <div class="col-lg-4 col-sm">
            <div class="card">
                <p>سڕینەوەی هەژمار</p>
                <p>ئەگەر ئەم هەژمارە بسڕیتەوە ئەوا هیچ پەیوەندییەکت نامێنێت بە رستەکۆدە و هەموو کڕینەکان دەسڕێنەوە
                    <b class="text-danger">ئەگەر دڵنیایت لە سڕینەوەی ئەم هەژمارە ئەوا کلیک لە سڕینەوە بکە</b>
                </p>
                <span class="btn btn-danger" data-toggle="modal" data-target="#delete">سڕینەوە</span>
            </div>
            <!-- Modal -->
            <div class="modal fade" wire:ignore.self id="delete" tabindex="-1" role="dialog"
                aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content bg-gradient-danger">
                        <div class="modal-body text-white">
                            <p>دڵنیایت لە سڕینەوەی ئەم هەژمارە؟</p>
                        </div>
                        <div class="text-center text-white my-3" wire:loading>
                            چاوەڕێ کە...
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-white" data-dismiss="modal">نەخێر</button>
                            <button type="button" wire:click="deleteAccount" class="btn btn-darker">بەڵێ دڵنیام</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>




    </div>

</div>
