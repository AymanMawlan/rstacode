<div class="container mt-3">
    <div class="bg-white p-1 rounded d-flex justify-content-between">
        <a href="/home" class="btn btn-darker ion-ios-undo rounded"></a>
        <span class="btn">ئاڵوگۆڕەکانم</span>
    </div>
    <table class="table table-white table-borderless table-responsive-sm table-hover rounded-lg mt-4" dir="rtl">
        <thead>
            <tr class="text-center">
                <th scope="col">Id</th>
                <th scope="col">باڵانس</th>
                <th scope="col">ژمارەی تەلەفوون</th>
                <th scope="col">حاڵەت</th>
                <th scope="col">کاتی ناردن</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($transactions as $transaction)
            <tr class="text-center">
                <th scope="row">{{$transaction->id}}</th>
                <td>{{number_format($transaction->balance ,0, '.' ,'.')." دینار "}}</td>
                <td>{{$transaction->phonenumber}}</td>
                <td
                    class="text-{{$transaction->status  == 1 ? "yellow ion-ios-stopwatch" : ($transaction->status  == 2 ? "success ion-android-checkmark-circle" : "danger  ion-ios-close") }}">
                    {{$transaction->status  == 1 ? "لە چاوەڕوانیدا" : ($transaction->status  == 2 ? "قبوڵ کرا" : "هەڵوەشایەوە") }}</td>
                <td dir="ltr">{{$transaction->updated_at->diffForHumans()}}</td>
            </tr>
            @endforeach

        </tbody>
    </table>
</div>
