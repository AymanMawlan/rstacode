<div class="container">
    @if($course->is_server == 0)
    <div class="text-center">
        <img src="{{ asset('/assets/img/load.svg')}}" class="img-fluid " width="100">
        <script>
            window.location = "{{$course->json_video}}";
        </script>
    </div>
    @else
    <div class="card p-0 mb-3">
        <div dir="ltr" class="media shadow mb-3 p-2 text-right">
            <div class="media-body mx-2">
                <b class="mt-0 display-4 text-capitalize">{{$course->teacher->name}}</b><br>
                <small>وانەبێژی خولەکە</small>
            </div>
            <span class="avatar rounded-lg ml-3">
                <img alt="Image placeholder" src="{{str_contains($course->teacher->picture, "https://") ? $course->teacher->picture :  asset('upload/picture/'.$course->teacher->picture)}}">
            </span>
        </div>
        @if (session()->has('message'))
        <div class="alert alert-success">
            {{ session('message') }}
        </div>
        @endif
        <div class="row no-gutters">
            <div class="col-md-8">
                <div class="card-body">
                    <h5 class="display-4">خولی فێربوونی : {{$course->title}}</h5>
                    <p class="mb-0 font-weight-light" style="word-spacing:5px; max-height: 120px;overflow: auto;">{{$course->description}}
                    </p>
                    <small class="text-muted">ژمارەی وانە : {{count($course->json_video )}} وانە</small><br>
                    <small class="text-muted">ژمارەی بەژداربووان : {{count($course->countOrder)}} بەژداربوو</small><br>
                    <h1>نرخی خولەکە :
                        {{$course->price > 0 ? number_format($course->price ,0, '.' ,'.')."دینارە " : "خۆڕایی "}}</h1>
                </div>
                {{-- Modal --}}
                @if($is_order == false)
                <button class="btn btn-dribbble" data-toggle="modal" data-target="#buy">کڕینی خولەکە</button>
                <div class="modal fade" id="buy" tabindex="-1" role="dialog" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-body text-center">
                                @if(Auth::check() && Auth::user()->balance >= $course->price)
                                <div wire:loading.remove wire:target="checkout">
                                    <p class="text-center">دڵنیایت لە کڕینی ئەم کۆرسە؟</p>
                                    <p class="text-center">نرخی ئەم کۆرسە :
                                        {{$course->price > 0 ? number_format($course->price ,0, '.' ,'.')."دینارە " : "خۆڕایی "}}
                                    </p>
                                    <button class="btn btn-primary" wire:click="checkout">بەڵێ</button>
                                    <button type="button" data-dismiss="modal" class="btn btn-danger">نەخێر</button>
                                </div>
                                <div class="text-center" wire:loading>
                                    <img src="{{asset('assets/img/load.svg')}}" width="200" alt="">
                                </div>
                                @elseif(Auth::check() && Auth::user()->balance < $course->price)
                                    <p class="display-1 text-center">باڵانسەکەت کەمە</p>
                                    @else
                                    <p class="display-1 text-center">تکایە بچۆ هەژمارەکەت</p>
                                    @endif
                            </div>
                        </div>
                    </div>
                </div>
                {{-- End Modal --}}
                @else
                <h1 class="display-3 mx-5 ion-android-checkmark-circle"></h1>
                @endif
            </div>
            <div class="col-md-4 d-none d-md-block">
                <img src="{{ asset("upload/courses/$course->image") }}" class="card-img">
            </div>
        </div>
    </div>
    <div class="row justify-content-center" id="playlist">
        <div class="col-sm-9">
            <div id="embedBox" class="embed-responsive-item" src="..."></div>
            <script>
                play(
                    '{{API::Video($mediaID."/otp")["otp"]}}',
                    '{{API::Video($mediaID."/otp")["playbackInfo"]}}'
                )
            </script>
        </div>
        <div class="col-sm-3" style="height: 500px;overflow: auto;">
            @foreach ($course->json_video as $i => $video)
            @if($is_order)
            <a href="/courses/{{$course->id}}/{{$video['id']}}/{{$i}}#playlist"
                class="media bg-white radius-10 shadow p-2 text-right m-2" dir="ltr">
                @else
                <div class="media bg-white radius-10 shadow p-2 text-right m-2" dir="ltr">
                    @endif
                    <div class="media-body">
                        <div class="d-flex justify-content-between">
                            <small class="text-muted" dir="rtl">{{gmdate("i:s",$video['length'])}}</small>
                            <small class="text-muted" dir="rtl">وانەی : {{$i+1}}</small>
                        </div>
                        <small dir="rtl">{{Str::limit($video['description'],28)}}</small>
                    </div>
                    <div class="position-relative ml-3">
                        <img src="{{$video['poster']}}" width="100" class="{{!$is_order && $i != 0 ? "blur" : ""}}">
                        <span
                            class="icon-sm icon-shape text-center {{!$is_order && $i != 0 ? "bg-danger" : ""}} play rounded-circle">
                            <i class="text-white {{!$is_order && $i != 0 ? "ion-android-lock" : "ion-play"}}"></i>
                        </span>
                    </div>
                    @if($is_order)
            </a>
            @else
        </div>
        @endif
        @endforeach
    </div>
</div>
@endif
<a href="/courses" class="btn btn-darker m-2 ion-ios-undo" style="position:fixed;bottom:0;left:0 "> گەڕانەوە </a>
</div>
