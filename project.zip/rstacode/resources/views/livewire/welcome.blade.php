<div class="container">
    <div wire:ignore.self class="jumbotron" data-aos="zoom-out">
        <span class="text-white">ڕستەکۆد</span>
        <h1 class="text-white">خانەیەک بۆ فێربوونی تۆی داڕێژەر</h1>
    </div>
        <p class="text-white">گەڕان بکە</p>
        <input type="text" placeholder="ناوی خوازیار" wire:model="search" class="form-control form-control-alternative radius-10">
        <div class="row">
            @foreach ($courses as $value)
            @include('livewire.content.card_course')
            @endforeach
        </div>
        {{ $courses->links() }}
    @if ($ShowBg)
    <div class="row position-fixed bottom-5 left-0 mb-2 ml-0 p-0" data-aos="zoom-out" style="width: 4rem;">
        @foreach ($bg_colors as $i => $bg)
        <div x-data @click="$wire.ChangeBg('{{$i}}')"
            class="icon icon-shape bg-gradient-{{$bg}} rounded-circle m-2 border border-white" style="cursor: pointer">
        </div>
        @endforeach
    </div>
    @endif
    <button wire:click.prefetch="toggleBg"
        class="icon icon-shape bg-gradient-{{session('bg')  ? session('bg') : "indigo"}} rounded-circle position-fixed border border-white bottom-0 left-0 m-2">
        <div class="text-center my-3" wire:loading>
            <img src="{{asset('assets/img/load.svg')}}" width="30">
        </div>
    </button>
</div>
