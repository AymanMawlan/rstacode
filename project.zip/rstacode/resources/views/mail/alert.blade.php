@component('mail::message')
<center>
    <div style="text-align: center !important;">
        <img src="https://cdn.dribbble.com/users/1162077/screenshots/5467854/bell-animation.gif" alt="">
        <center dir="rtl">
            کەسێک پارەی بۆ ناردویت تکایە سەردانی وێبسایت بکە بۆ زانیاری زیاتر
        </center>
    </div>
</center>
@endcomponent
