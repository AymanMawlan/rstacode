<?php
use Illuminate\Support\Facades\Route;

Route::group(['middleware' => 'throttle:60,1'],function(){
Auth::routes(['verify' => true]);
Route::get('/', \App\Http\Livewire\Welcome::class);
Route::get('/x', \App\Http\Livewire\Welcome::class);

Route::get('/courses', \App\Http\Livewire\Welcome::class);
Route::get('/about', \App\Http\Livewire\About::class);


Route::get('/courses/{id}', \App\Http\Livewire\ViewCourse::class);
Route::get('/courses/{id}/{mediaID}/{i}', \App\Http\Livewire\ViewCourse::class);

Route::get('login/{provider}', [App\Http\Controllers\Auth\SocialAPI::class, 'redirectToProvider']);
Route::get('login/{provider}/callback', [App\Http\Controllers\Auth\SocialAPI::class, 'handleProviderCallback']);

// // ============================================== User Profile
Route::group(['middleware' => ['auth' , 'verified']],function(){

Route::get('/home', \App\Http\Livewire\Profile\Home::class);
Route::get('/home/course', \App\Http\Livewire\Profile\OrderCourses::class);
Route::get('/home/transaction', \App\Http\Livewire\Profile\Transaction::class);
Route::get('/home/settings', \App\Http\Livewire\Profile\Settings::class);


});




});
